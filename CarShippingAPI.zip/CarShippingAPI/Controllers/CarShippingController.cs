﻿using CarShippingAPI.Models;
using CarShippingAPI.ProcessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;

namespace CarShippingAPI.Controllers
{
    public class CarShippingController : ApiController
    {
        // GET: api/CarShipping
        //public IEnumerable<string> Get()
        //{
        //    return new string[] { "value1", "value2" };
        //}

        // GET: api/CarShipping/5
        //public string Get(int id)
        //{
        //    return "value";
        //}

        // POST: api/CarShipping
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/CarShipping/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/CarShipping/5
        public void Delete(int id)
        {
        }
        private VehicleDetails db = new VehicleDetails();

        [Route("api/AuctionDetails")]
        public HttpResponseMessage Get()
        {
            var _mycar = CarsRepositoryOps.GetAllCarDetails();
            HttpResponseMessage _response = Request.CreateResponse(HttpStatusCode.OK, _mycar);
            return _response;
        }

        //GET: api/AuctionDetails/5
        //[ResponseType(typeof(AuctionDetail))]
        //public IHttpActionResult GetAuctionDetail(string id)
        //{
        //    AuctionDetail auctionDetail = db.AuctionDetails.Find(id);

        //    if (auctionDetail == null)
        //    {
        //        return NotFound();
        //    }

        //    return Ok(auctionDetail);
        //}

        // GET api/ptemployees/5

        [Route("api/AuctionDetails/{id?}")]
        public HttpResponseMessage Get(int id)
        {
            var _mycar = CarsRepositoryOps.GetCarDetails(id);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, _mycar);
            return response;
        }

        [Route("api/AuctionDetails/GetAllLocationsByBuyerId/{id?}")]
        public HttpResponseMessage GetAllLocationsByBuyerId(int id)
        {
            var _mycar = CarsRepositoryOps.GetAllLocationsByBuyerId(id);
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK, _mycar);
            return response;
        }

        #region default code..not used

        // PUT: api/AuctionDetails/5
        [ResponseType(typeof(void))]
        //public IHttpActionResult PutAuctionDetail(string id, AuctionDetail auctionDetail)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    if (id != auctionDetail.ID)
        //    {
        //        return BadRequest();
        //    }

        //    db.Entry(auctionDetail).State = EntityState.Modified;

        //    try
        //    {
        //        db.SaveChanges();
        //    }
        //    catch (DbUpdateConcurrencyException)
        //    {
        //        if (!AuctionDetailExists(id))
        //        {
        //            return NotFound();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return StatusCode(HttpStatusCode.NoContent);
        //}

        // POST: api/AuctionDetails
        [ResponseType(typeof(AuctionDetail))]
        //public IHttpActionResult PostAuctionDetail(AuctionDetail auctionDetail)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        return BadRequest(ModelState);
        //    }

        //    db.AuctionDetails.Add(auctionDetail);

        //    try
        //    {
        //        db.SaveChanges();
        //    }
        //    catch (DbUpdateException)
        //    {
        //        if (AuctionDetailExists(auctionDetail.ID))
        //        {
        //            return Conflict();
        //        }
        //        else
        //        {
        //            throw;
        //        }
        //    }

        //    return CreatedAtRoute("DefaultApi", new { id = auctionDetail.ID }, auctionDetail);
        //}
        #endregion
        // DELETE: api/AuctionDetails/5
        [ResponseType(typeof(AuctionDetail))]
        public IHttpActionResult DeleteAuctionDetail(string id)
        {
            AuctionDetail auctionDetail = db.AuctionDetails.Find(id);
            if (auctionDetail == null)
            {
                return NotFound();
            }

            db.AuctionDetails.Remove(auctionDetail);
            db.SaveChanges();

            return Ok(auctionDetail);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
