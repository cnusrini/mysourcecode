﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace CarShippingAPI.Models
{
    

    public partial class AuctionDetail
    {
        [Key]
        [Column(Order = 0)]
        [StringLength(50)]
        public string ID { get; set; }

        [StringLength(50)]
        public string Make { get; set; }

        [Key]
        [Column(Order = 1)]
        [StringLength(50)]
        public string Model { get; set; }

        [Key]
        [Column(Order = 2)]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int Year { get; set; }

        [Key]
        [Column(Order = 3)]
        [StringLength(255)]
        public string Trim { get; set; }

        [Key]
        [Column(Order = 4)]
        [StringLength(255)]
        public string Description { get; set; }

        [Key]
        [Column(Order = 5)]
        [StringLength(255)]
        public string Class { get; set; }

        [StringLength(50)]
        public string PaymentDone { get; set; }

        [StringLength(50)]
        public string IsPicked { get; set; }

        [StringLength(255)]
        public string BuyerID { get; set; }

        [Key]
        [Column(Order = 6)]
        [StringLength(50)]
        public string Location { get; set; }
    }
}