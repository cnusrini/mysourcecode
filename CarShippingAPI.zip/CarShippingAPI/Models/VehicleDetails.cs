﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace CarShippingAPI.Models
{
   

    public partial class VehicleDetails : DbContext
    {
        public VehicleDetails()
            : base("name=VehicleDetails")
        {
        }

        public virtual DbSet<AuctionDetail> AuctionDetails { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AuctionDetail>()
                .Property(e => e.ID)
                .IsUnicode(false);

            modelBuilder.Entity<AuctionDetail>()
                .Property(e => e.Make)
                .IsUnicode(false);

            modelBuilder.Entity<AuctionDetail>()
                .Property(e => e.Model)
                .IsUnicode(false);

            modelBuilder.Entity<AuctionDetail>()
                .Property(e => e.Trim)
                .IsUnicode(false);

            modelBuilder.Entity<AuctionDetail>()
                .Property(e => e.Description)
                .IsUnicode(false);

            modelBuilder.Entity<AuctionDetail>()
                .Property(e => e.Class)
                .IsUnicode(false);

            modelBuilder.Entity<AuctionDetail>()
                .Property(e => e.PaymentDone)
                .IsUnicode(false);

            modelBuilder.Entity<AuctionDetail>()
                .Property(e => e.IsPicked)
                .IsUnicode(false);

            modelBuilder.Entity<AuctionDetail>()
                .Property(e => e.BuyerID)
                .IsUnicode(false);

            modelBuilder.Entity<AuctionDetail>()
                .Property(e => e.Location)
                .IsUnicode(false);
        }
    }
}