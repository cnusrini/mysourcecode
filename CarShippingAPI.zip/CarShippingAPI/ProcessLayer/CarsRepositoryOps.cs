﻿using CarShippingAPI.Models;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CarShippingAPI.ProcessLayer
{
    public class CarsRepositoryOps
    {
        private static VehicleDetails db = new VehicleDetails();
        
        //Get car details where Lot number or stock number if provided
        public static AuctionDetail GetCarDetails(int _lotnumber)
        {
            
            var _GetCarsQuery = from _cars in db.AuctionDetails
                                where _cars.ID == _lotnumber.ToString()
                        select _cars;
            return _GetCarsQuery.SingleOrDefault();
        }

        //Get all cars
        public static List<AuctionDetail> GetAllCarDetails()
        {
            var _GetAllCarsQuery = from _car in db.AuctionDetails
                                   select _car;
            return _GetAllCarsQuery.ToList();
        }

        //Get All location by BuyerID
        public static List<AuctionDetail> GetAllLocationsByBuyerId(int _buyerid)
        {
            var _GetAllLocations = from _locations in db.AuctionDetails
                                   where _locations.BuyerID == _buyerid.ToString()
                                   select _locations;
            return _GetAllLocations.ToList();

        }
    }
}